package final_project;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Shadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Mains extends Application {

	Background background;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {

		// Rectangle box 1
		Rectangle rect1 = new Rectangle();
		rect1.setWidth(250);
		rect1.setHeight(150);
		rect1.setFill(Color.AQUA);
		rect1.setArcHeight(15);
		rect1.setArcWidth(15);
		// Image box 1
		Image pic1 = new Image("pharmacy.png");
		ImageView ivpic1 = new ImageView(pic1);
		ivpic1.setFitHeight(50);
		ivpic1.setFitWidth(50);
		// text box 1
		Text txt1 = new Text("PHARMACY");
		StackPane sp1 = new StackPane();
		sp1.getChildren().addAll(rect1, txt1);
		txt1.setFont(Font.font("Ariel",FontWeight.BOLD,20));
		txt1.setTextAlignment(TextAlignment.JUSTIFY);
		txt1.setFill(Color.WHITE);
		//Creating a Shadow
		DropShadow shadow1 = new DropShadow();
		shadow1.setOffsetX(5);
		shadow1.setOffsetY(5);
		shadow1.setColor(Color.rgb(20,20,20,0.5));
		txt1.setEffect(shadow1);
		
		// Rectangle box 2
		Rectangle rect2 = new Rectangle();
		rect2.setWidth(250);
		rect2.setHeight(150);
		rect2.setFill(Color.CORNFLOWERBLUE);
		rect2.setArcHeight(15);
		rect2.setArcWidth(15);
		// Image box 2
		Image pic2 = new Image("neurology.png");
		ImageView ivpic2 = new ImageView(pic2);
		ivpic2.setFitHeight(50);
		ivpic2.setFitWidth(50);
		// text box 2
		Text txt2 = new Text("NEUROLOGY");
		StackPane sp2 = new StackPane();
		sp2.getChildren().addAll(rect2, txt2);
		txt2.setFont(Font.font("Ariel",FontWeight.BOLD,20));
		txt2.setTextAlignment(TextAlignment.JUSTIFY);
		txt2.setFill(Color.WHITE);
		//Creating a shadow
		DropShadow shadow2 = new DropShadow();
		shadow2.setOffsetX(5);
		shadow2.setOffsetY(5);
		shadow2.setColor(Color.rgb(20,20,20,0.5));
		txt2.setEffect(shadow2);

		
		// Rectangle box 3
		Rectangle rect3 = new Rectangle();
		rect3.setWidth(250);
		rect3.setHeight(150);
		rect3.setFill(Color.YELLOW);
		rect3.setArcHeight(15);
		rect3.setArcWidth(15);
		// Image box 3
		Image pic3 = new Image("cardiology.png");
		ImageView ivpic3 = new ImageView(pic3);
		ivpic3.setFitWidth(50);
		ivpic3.setFitHeight(50);
		// text box 3
		Text txt3 = new Text("CARDIOLOGY");
		StackPane sp3 = new StackPane();
		sp3.getChildren().addAll(rect3, txt3);
		txt3.setFont(Font.font("Ariel",FontWeight.BOLD,20));
		txt3.setTextAlignment(TextAlignment.JUSTIFY);
		txt3.setFill(Color.WHITE);
		//Creating a shadow
		DropShadow shadow3 = new DropShadow();
		shadow3.setOffsetX(5);
		shadow3.setOffsetY(5);
		shadow3.setColor(Color.rgb(20,20,20,0.5));
		txt3.setEffect(shadow3);
		HBox h1 = new HBox(10, sp1, sp2, sp3, ivpic1, ivpic2, ivpic3);

		
		// Rectangle box 4
		Rectangle rect4 = new Rectangle();
		rect4.setWidth(250);
		rect4.setHeight(150);
		rect4.setFill(Color.CHARTREUSE);
		rect4.setArcHeight(15);
		rect4.setArcWidth(15);
		// Image box 4
		Image pic4 = new Image("surgery.png");
		ImageView ivpic4 = new ImageView(pic4);
		ivpic4.setFitWidth(50);
		ivpic4.setFitHeight(50);
		// Text box 4
		Text txt4 = new Text("SURGERY");
		StackPane sp4 = new StackPane();
		sp4.getChildren().addAll(rect4, txt4);
		txt4.setFont(Font.font("Ariel",FontWeight.BOLD,20));
		txt4.setTextAlignment(TextAlignment.JUSTIFY);
		txt4.setFill(Color.WHITE);
		//Creating a shadow
		DropShadow shadow4 = new DropShadow();
		shadow4.setOffsetX(5);
		shadow4.setOffsetY(5);
		shadow4.setColor(Color.rgb(20,20,20,0.5));
		txt4.setEffect(shadow4);

		
		// Rectangle box 5
		Rectangle rect5 = new Rectangle();
		rect5.setWidth(250);
		rect5.setHeight(150);
		rect5.setFill(Color.DARKGREEN);
		rect5.setArcHeight(15);
		rect5.setArcWidth(15);
		// Image box 5
		Image pic5 = new Image("Physiotherapy.png");
		ImageView ivpic5 = new ImageView(pic5);
		ivpic5.setFitWidth(50);
		ivpic5.setFitHeight(50);
		// Text box 5
		Text txt5 = new Text("PHYSIOTHERAPY");
		StackPane sp5 = new StackPane();
		sp5.getChildren().addAll(rect5, txt5);
		txt5.setFont(Font.font("Ariel",FontWeight.BOLD,20));
		txt5.setTextAlignment(TextAlignment.JUSTIFY);
		txt5.setFill(Color.WHITE);
		//Creating a shadow
		DropShadow shadow5 = new DropShadow();
		shadow5.setOffsetX(5);
		shadow5.setOffsetY(5);
		shadow5.setColor(Color.rgb(20,20,20,0.5));
		txt5.setEffect(shadow5);

		
		// Rectangle box 6
		Rectangle rect6 = new Rectangle();
		rect6.setWidth(250);
		rect6.setHeight(150);
		rect6.setFill(Color.DARKSEAGREEN);
		rect6.setArcHeight(15);
		rect6.setArcWidth(15);
		// Image box 5
		Image pic6 = new Image("Generalphysician.png");
		ImageView ivpic6 = new ImageView(pic6);
		ivpic6.setFitWidth(50);
		ivpic6.setFitHeight(50);
		// Text box 5
		Text txt6 = new Text("GENERAL PHYSICIAN");
		StackPane sp6 = new StackPane();
		sp6.getChildren().addAll(rect6, txt6);
		txt6.setFont(Font.font("Ariel",FontWeight.BOLD,20));
		txt6.setTextAlignment(TextAlignment.JUSTIFY);
		txt6.setFill(Color.WHITE);
		//Creating a shadow
		DropShadow shadow6 = new DropShadow();
		shadow6.setOffsetX(5);
		shadow6.setOffsetY(5);
		shadow6.setColor(Color.rgb(20,20,20,0.5));
		txt6.setEffect(shadow6);
		HBox h2 = new HBox(10, sp4, sp5, sp6, ivpic4, ivpic5, ivpic6);
		
		Button bt1 = new Button("Logout");
		bt1.setWrapText(true);
		GridPane gp = new GridPane();
		gp.setHgap(20);
		gp.setVgap(20);
		gp.add(bt1, 92, 1);
//		bt1.setOnMouseEntered(new EventHandler() {
//		    public void handle(MouseEvent me) {
//		        scene.setCursor(Cursor.HAND); //Change cursor to hand
//		    }
//
//			@Override
//			public void handle(Event event) {
//				// TODO Auto-generated method stub
//				
//			}
//		});
		
		VBox layout = new VBox(10, gp, h1, h2);
		Scene scene = new Scene(layout, 1000, 600);
		scene.setFill(Color.ALICEBLUE);

		primaryStage.setTitle("DASHBOARD");
		primaryStage.setScene(scene);
		primaryStage.show();

	}

}
